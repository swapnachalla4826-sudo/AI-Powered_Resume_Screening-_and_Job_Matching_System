"""
Resume Data Analyzer
Load data.csv, print stats: row count, top skills, avg matched_score, top job positions.
"""

import ast
import csv
from collections import Counter

CSV_PATH = "data.csv"


def safe_list(val):
    """Parse stringified python list column, return [] on failure."""
    try:
        parsed = ast.literal_eval(val)
        return parsed if isinstance(parsed, list) else [val]
    except (ValueError, SyntaxError):
        return [val] if val else []


def main():
    rows = 0
    skill_counter = Counter()
    job_counter = Counter()
    scores = []

    with open(CSV_PATH, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows += 1

            for s in safe_list(row.get("skills", "")):
                skill_counter[s.strip()] += 1

            job = (row.get("job_position_name") or row.get("\ufeffjob_position_name") or "").strip()
            if job:
                job_counter[job] += 1

            score = row.get("matched_score", "")
            try:
                scores.append(float(score))
            except ValueError:
                pass

    print(f"Total rows: {rows}")
    print(f"\nTop 10 skills:")
    for skill, cnt in skill_counter.most_common(10):
        print(f"  {skill}: {cnt}")

    print(f"\nTop 10 job positions:")
    for job, cnt in job_counter.most_common(10):
        print(f"  {job}: {cnt}")

    if scores:
        print(f"\nMatched score: avg={sum(scores)/len(scores):.3f}, "
              f"min={min(scores):.3f}, max={max(scores):.3f}, n={len(scores)}")


if __name__ == "__main__":
    main()
