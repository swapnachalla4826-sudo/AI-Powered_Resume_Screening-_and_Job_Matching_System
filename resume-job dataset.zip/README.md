# Resume Data Project

## Files
- `data.csv` — resume dataset, 9,544 rows, 35 cols.
- `analyze.py` — parses csv, prints stats.
- `README.md` — this file.

## Columns (key ones)
- `skills` — stringified list, candidate skills.
- `professional_company_names`, `positions` — work history.
- `job_position_name` — target job title (col header has stray BOM char, script handles it).
- `matched_score` — 0-1 float, resume-to-job match score.

## Run
```
python3 analyze.py
```
Outputs: total rows, top 10 skills, top 10 job positions, matched_score avg/min/max.

## Note
List-like cols (skills, dates, etc) stored as Python-list strings — parse with `ast.literal_eval`, not `json.loads` (single quotes break JSON).
